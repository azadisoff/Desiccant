<?php

//INPUT USER-AGENT
$user = 'xxx';

//INPUT COOKIE
$cookie = 'xxx';